<?php
  session_start();
  if(!isset($_SESSION['loggedin'])){
    header("location: ./login_page.php");
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="./CSS/sale-styling.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Sales</title>
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous" />

  <!--JAVASCRIPT-->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
    integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
    crossorigin="anonymous"></script>
  <script>
    function displayBlock() {
      document.getElementById('Box').style.display = "block";
      document.getElementById('table').style.display = "none";
    }

    function displayNone() {
      document.getElementById('Box').style.display = "none";
      document.getElementById('table').style.display = "block";
    }

    if ( window.history.replaceState ) {
      window.history.replaceState( null, null, window.location.href );
    }
    
  </script>

</head>

<body>
  <div id="Box">
    <div class="New-Box">
      <h2 style="text-align:center;"><span onclick="displayNone()"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-left" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8z"/>
  </svg></span> Report </h2> <br>

    <?php
      include './Partials/_dbconnect.php';
      if($_GET['time'] == 'day'){
        $mspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where day(s_date)-day(CURRENT_DATE)=0 
                 and STATUS='sale' group by p_id order by total desc)  as t1 limit 1) as t2 join item on item.P_id=t2.p_id;";
        $lspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where day(s_date)-day(CURRENT_DATE)=0 
                and STATUS='sale' group by p_id order by total asc) 
                as t1 limit 1) as t2 join item on item.P_id=t2.p_id";
        $mppQ = "SELECT Brand, Model from item where p_id = (select p_id from (select item.P_id, (t1.ASUM - t1.total*item.cost)/t1.total as mpp from (SELECT 
                p_id,sum(quantity) as total , sum(amount) as ASUM from sale where day(s_date)-day(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 
                join item on item.P_id=t1.p_id group by item.P_id order by mpp desc) as t2 limit 1);";
        $pQ = "SELECT sum(total) as PROFIT from (select item.P_id, (t1.ASUM - t1.total*item.cost) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where day(s_date)-day(CURRENT_DATE)=0  and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2;";
        $lQ = "SELECT sum(total) as LOSS from (select item.P_id, (t1.ASUM - t1.total*item.Price) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where day(s_date)-day(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2";
      }
      elseif($_GET['time'] == 'month'){
        $mspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where month(s_date)-month(CURRENT_DATE)=0 
                 and STATUS='sale' group by p_id order by total desc)  as t1 limit 1) as t2 join item on item.P_id=t2.p_id;";
        $lspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where month(s_date)-month(CURRENT_DATE)=0 
                 and STATUS='sale' group by p_id order by total asc) 
                 as t1 limit 1) as t2 join item on item.P_id=t2.p_id";
        $mppQ = "SELECT Brand, Model from item where p_id = (select p_id from (select item.P_id, (t1.ASUM - t1.total*item.cost)/t1.total as mpp from (SELECT 
                 p_id,sum(quantity) as total , sum(amount) as ASUM from sale where month(s_date)-month(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 
                 join item on item.P_id=t1.p_id group by item.P_id order by mpp desc) as t2 limit 1);";
        $pQ = "SELECT sum(total) as PROFIT from (select item.P_id, (t1.ASUM - t1.total*item.cost) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where month(s_date)-month(CURRENT_DATE)=0  and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2;";
        $lQ = "SELECT sum(total) as LOSS from (select item.P_id, (t1.ASUM - t1.total*item.Price) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where month(s_date)-month(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2";
        } 
      elseif($_GET['time'] == 'year'){
        $mspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where year(s_date)-year(CURRENT_DATE)=0 
                 and STATUS='sale' group by p_id order by total desc)  as t1 limit 1) as t2 join item on item.P_id=t2.p_id;";
        $lspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where year(s_date)-year(CURRENT_DATE)=0 
                and STATUS='sale' group by p_id order by total asc) 
                as t1 limit 1) as t2 join item on item.P_id=t2.p_id";
        $mppQ = "SELECT Brand, Model from item where p_id = (select p_id from (select item.P_id, (t1.ASUM - t1.total*item.cost)/t1.total as mpp from (SELECT 
                p_id,sum(quantity) as total , sum(amount) as ASUM from sale where year(s_date)-year(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 
                join item on item.P_id=t1.p_id group by item.P_id order by mpp desc) as t2 limit 1);";
        $pQ = "SELECT sum(total) as PROFIT from (select item.P_id, (t1.ASUM - t1.total*item.cost) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where year(s_date)-year(CURRENT_DATE)=0  and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2;";
        $lQ = "SELECT sum(total) as LOSS from (select item.P_id, (t1.ASUM - t1.total*item.Price) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where year(s_date)-year(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2";
        }
      else{
        $mspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where day(s_date)-day(CURRENT_DATE)=0 
                 and STATUS='sale' group by p_id order by total desc)  as t1 limit 1) as t2 join item on item.P_id=t2.p_id;";
        $lspQ = "SELECT Brand,Model from (select p_id from (SELECT p_id,sum(quantity) as total , sum(amount) from sale where day(s_date)-day(CURRENT_DATE)=0 
                and STATUS='sale' group by p_id order by total asc) 
                as t1 limit 1) as t2 join item on item.P_id=t2.p_id";
        $mppQ = "SELECT Brand, Model from item where p_id = (select p_id from (select item.P_id, (t1.ASUM - t1.total*item.cost)/t1.total as mpp from (SELECT 
                p_id,sum(quantity) as total , sum(amount) as ASUM from sale where day(s_date)-day(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 
                join item on item.P_id=t1.p_id group by item.P_id order by mpp desc) as t2 limit 1);";
        $pQ = "SELECT sum(total) as PROFIT from (select item.P_id, (t1.ASUM - t1.total*item.cost) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where day(s_date)-day(CURRENT_DATE)=0  and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2;";
        $lQ = "SELECT sum(total) as LOSS from (select item.P_id, (t1.ASUM - t1.total*item.Price) as total from (SELECT p_id,sum(quantity) as total , 
               sum(amount) as ASUM from sale where day(s_date)-day(CURRENT_DATE)=0 and STATUS='sale' group by p_id ) as t1 join item on item.P_id=t1.p_id 
               group by item.P_id) as t2";
      }        

      $q1 = mysqli_query($conn, $mspQ);
      $q2 = mysqli_query($conn, $lspQ);
      $q3 = mysqli_query($conn, $mppQ);
      $q4 = mysqli_query($conn, $pQ);
      $q5 = mysqli_query($conn, $lQ);

      $r1 = mysqli_fetch_assoc($q1);
      $r2 = mysqli_fetch_assoc($q2);
      $r3 = mysqli_fetch_assoc($q3);
      $r4 = mysqli_fetch_assoc($q4);
      $r5 = mysqli_fetch_assoc($q5);
    ?>

  Most Selling Product<br>
<p style="font-size: 3vh; text-align:center">  <?php echo $r1['Brand']."  ".$r1['Model']." <br> <br> "; ?>  </p>
  Least Selling Product<br>
<p style="font-size: 3vh; text-align:center">  <?php echo $r2['Brand']."  ".$r3['Model']." <br> <br> "; ?>  </p>
  Most Profitable Product<br>
<p style="font-size: 3vh; text-align:center">  <?php echo $r3['Brand']."  ".$r3['Model']." <br> <br> "; ?>  </p>
  Profit<br>
<p style="font-size: 3vh; text-align:center">  <?php echo $r4['PROFIT']." <br> <br> "; ?> </p>
  Loss<br>  
<p style="font-size: 3vh; text-align:center">  <?php echo $r5['LOSS']." <br> <br> "; ?> </p> 

    </div>
  </div>

  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <div class="container-fluid" >
        <a class="navbar-brand" href="#" style="font-size: 5.5vh; font-family: cursive;">InvenTrack</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
        aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="Search" id="navbarCollapse">
          <a href="./logout.php">Logout <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" class="bi bi-power" viewBox="0 0 16 16">
              <path d="M7.5 1v7h1V1h-1z" />
              <path d="M3 8.812a4.999 4.999 0 0 1 2.578-4.375l-.485-.874A6 6 0 1 0 11 3.616l-.501.865A5 5 0 1 1 3 8.812z" />
            </svg></a>
        </div>
    </div>
  </nav>

  <?php
  if(isset($_GET['time'])){
    if($_SERVER['REQUEST_METHOD'] == 'GET'){
      include './Partials/_dbconnect.php';
        if($_GET['time'] == 'day'){
            $q = "SELECT * from sale where day(s_date) - day(CURRENT_DATE) = 0 and month(s_date) - month(CURRENT_DATE) = 0 and year(s_date) - year(CURRENT_DATE) = 0";
            $result = mysqli_query($conn, $q);
        }
        elseif($_GET['time'] == 'month'){
            $q = "SELECT * from sale where month(s_date) - month(CURRENT_DATE) = 0 and year(s_date) - year(CURRENT_DATE) = 0";
            $result = mysqli_query($conn, $q);
        }
        elseif($_GET['time'] == 'year'){
            $q = "SELECT * from sale where year(s_date) - year(CURRENT_DATE) = 0";
            $result = mysqli_query($conn, $q);
        }
    }
    }
  ?>

  <div class="sort">
    <form method="get" action="sales.php">
       Sort by:<select name="time"><option disabled selected value> -- select an option -- </option>
            <option value="day">Today</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
            </select>
            <input type="submit" value="SUBMIT" style=" background-color: rgb(7, 52, 186); color:white;">
    </form>
  </div>

  <main>
  <div>
    <ul>
        <li><a href="./Home-page.php">Home</a></li>
        <li><a href="./Customer-page.php">Customers</a></li>
        <li><a href="./Supplier-Page.php">Suppliers</a></li>
        <li><a href="./Items.php">Items</a></li>
        <li><a href="./sales.php">Sales</a></li>
    </ul>
  </div>

  <div style="overflow-x:auto;">
      <table id="table">
        <tr>
          <th style="width: 11%;"> Sale No.</th>
          <th style="width: 11%;"> Sale Date</th>
          <th style="width: 13%;"> Quantity</th>
          <th style="width: 20%;"> Amount</th>
          <th style="width: 30%;"> C_id</th>
          
        </tr>
      <tbody>
          <?php
            include './Partials/_dbconnect.php';
            if(!isset($_GET['time'])){
            $Query = "SELECT * FROM `sale`"; 
            $result = mysqli_query($conn, $Query); }

            $num = mysqli_num_rows($result);   //to fetch the number of rows in table

            // mysqli_fetch_assoc($res) this function returns the next row in table 
            if($num>0){
            while($row = mysqli_fetch_assoc($result)){ ?>
              <tr>
                <td> <?php echo $row['sale_no'];  ?> </td>
                <td> <?php echo $row['s_date'];  ?> </td>
                <td> <?php echo $row['quantity'];  ?> </td>
                <td> <?php echo $row['amount'];  ?> </td>
                <td> <?php echo $row['c_id'];  ?> </td>
                
              </tr>  
            <?php } 
          }?>
           
      </tbody>
      </table>
    </div>


    <div class="Report" onclick="displayBlock()">
      <span><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-file-earmark-pdf" viewBox="0 0 16 16">
  <path d="M14 14V4.5L9.5 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2zM9.5 3A1.5 1.5 0 0 0 11 4.5h2V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1h5.5v2z"/>
  <path d="M4.603 14.087a.81.81 0 0 1-.438-.42c-.195-.388-.13-.776.08-1.102.198-.307.526-.568.897-.787a7.68 7.68 0 0 1 1.482-.645 19.697 19.697 0 0 0 1.062-2.227 7.269 7.269 0 0 1-.43-1.295c-.086-.4-.119-.796-.046-1.136.075-.354.274-.672.65-.823.192-.077.4-.12.602-.077a.7.7 0 0 1 .477.365c.088.164.12.356.127.538.007.188-.012.396-.047.614-.084.51-.27 1.134-.52 1.794a10.954 10.954 0 0 0 .98 1.686 5.753 5.753 0 0 1 1.334.05c.364.066.734.195.96.465.12.144.193.32.2.518.007.192-.047.382-.138.563a1.04 1.04 0 0 1-.354.416.856.856 0 0 1-.51.138c-.331-.014-.654-.196-.933-.417a5.712 5.712 0 0 1-.911-.95 11.651 11.651 0 0 0-1.997.406 11.307 11.307 0 0 1-1.02 1.51c-.292.35-.609.656-.927.787a.793.793 0 0 1-.58.029zm1.379-1.901c-.166.076-.32.156-.459.238-.328.194-.541.383-.647.547-.094.145-.096.25-.04.361.01.022.02.036.026.044a.266.266 0 0 0 .035-.012c.137-.056.355-.235.635-.572a8.18 8.18 0 0 0 .45-.606zm1.64-1.33a12.71 12.71 0 0 1 1.01-.193 11.744 11.744 0 0 1-.51-.858 20.801 20.801 0 0 1-.5 1.05zm2.446.45c.15.163.296.3.435.41.24.19.407.253.498.256a.107.107 0 0 0 .07-.015.307.307 0 0 0 .094-.125.436.436 0 0 0 .059-.2.095.095 0 0 0-.026-.063c-.052-.062-.2-.152-.518-.209a3.876 3.876 0 0 0-.612-.053zM8.078 7.8a6.7 6.7 0 0 0 .2-.828c.031-.188.043-.343.038-.465a.613.613 0 0 0-.032-.198.517.517 0 0 0-.145.04c-.087.035-.158.106-.196.283-.04.192-.03.469.046.822.024.111.054.227.09.346z"/>
</svg> Report</span>
    </div>
        </main>

    <footer>
      <p style="padding-bottom: 90%;"></p>
        </footer>
</body>

</html>