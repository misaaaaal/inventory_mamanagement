<?php
$cid=0;
include './Partials/_dbconnect.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $num = $_POST["number"];
        $query="SELECT * from `customer` where `contact`='$num'";
        $res=mysqli_query($conn, $query);
        $row=mysqli_num_rows($res);
        echo $row;
        if($row!=0){
            $cstmr=mysqli_fetch_assoc($res);
            $cid=$cstmr["c_id"];
            $query="UPDATE  `customer` set `discoins`=`discoins`+50 where `c_id`='$cid'";
            $res=mysqli_query($conn, $query);
        }
    }
  ?>