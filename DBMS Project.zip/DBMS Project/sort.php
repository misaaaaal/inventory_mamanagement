<?php
include './Partials/_dbconnect.php';
$output='';
$order=$_POST["order"];
if($order=='desc'){
    $order='asc';
}
else{
    $order='desc';
}
$query="SELECT * from `item` ORDER BY '.$_POST['column_name'].' '.$_POST['order']'";
$result=mysqli_query($conn,$query);
$output .='send
<table>
        <tr>
          <th style="width: 11%;" class="column_sort" id="id" data-order="'.$order.'" href="#"> Product no.</th>
          <th style="width: 11%;"> Type</th>
          <th style="width: 13%;"> Brand</th>
          <th style="width: 20%;"> Model</th>
          <th style="width: 30%;" class="column_sort" id="price" data-order="'.$order.'" href="#"> Price</th>
          <th style="width: 30%;"> Add to Sale</th>
          <th style="width: 15%;" class="column_sort" id="quantity" data-order="'.$order.'" href="#"> Quantity in stock</th>
          <th></th>
        </tr>
';
while($row=mysqli_fetch_array($result)){
    $output .='
    <tr>
                <td> <?php echo $row['P_id'];  ?> </td>
                <td> <?php echo $row['Type'];  ?> </td>
                <td> <?php echo $row['Brand'];  ?> </td>
                <td> <?php echo $row['Model'];  ?> </td>
                <td> <?php echo $row['Price'];  ?> </td>
                <td> <?php echo "<a href='removefromcart.php?pid=$row[P_id]'><button style='font-size:24px background-color: transparent;' class='fa'>&#xf068</button></a> &nbsp&nbsp";?>
                    <?php
                        $q="SELECT * from `sale`";
                        $r=mysqli_query($conn, $q);
                        if(mysqli_num_rows($r)==0){
                          echo "0";
                        }
                        else{
                          $q="SELECT * from `sale` where `p_id`='$row[P_id]' and `status`='cart'";
                          $r=mysqli_query($conn,$q);
                          if(mysqli_num_rows($r)==0){
                            echo "0";
                          }
                          else{
                            $q=mysqli_fetch_assoc($r);
                            echo $q["quantity"];
                          }
                        }
                    ?>
                  <?php  echo "<a href='addtocart.php?pid=$row[P_id]'><button style='font-size:24px background-color: transparent;' class='fa'>&#xf067;</button></a>"; ?>
                <td> <?php echo $row['Quantity'];  ?> </td>
                <td><?php echo "<a href='Items.php?pid=$row[P_id]' onclick='return checkdel()'><button class=\"del\">Delete</button></a>" ?></td>
              </tr> 
    ';
}
$output .='</table>';
echo $output;
?>









// <?php
// $salechange="UPDATE `sale` set `status`='sale' where `c_id`='$cid'";
// $qr=mysqli_query($conn, $salechange);
// $ml="SELECT * from `customer` where `c_id`='$cid'";
// $r=mysqli_query($conn,$ml);
// $row=mysqli_fetch_assoc($r);
// $receiver = "$row[email]";
// $reciever="misaalraikar1@gmail.com";
// $subject = "Email Test via PHP using Localhost";
// $body = "Hi, there...This is a test email send from Localhost.";
// $pdfLocation = "C:\Users\User1\Downloads/7.pdf"; // file location
// // $pdfName     = $filename; // pdf file name recipient will get
// $pdfName="7.pdf";
// $filetype="application/pdf"; // type
// // $sender = "From:misaalraikar1@gmail,com";
// $sender = "misaalraikar1@gmail.com";
// // if(mail($receiver, $subject, $body, $sender)){
// //     echo "Email sent successfully to $receiver";
// // }else{
// //     echo "Sorry, failed while sending mail!";
// // }

// $eol = PHP_EOL;
// $semi_rand     = md5(time());
// $mime_boundary = "==Multipart_Boundary_x{$semi_rand}x";
// $headers       = "From: $sender$eol" .
//   "MIME-Version: 1.0$eol" .
//   "Content-Type: multipart/mixed;$eol" .
//   " boundary=\"$mime_boundary\"";


// $message = "--$mime_boundary$eol" .
// "Content-Type: text/html; charset=\"iso-8859-1\"$eol" .
// "Content-Transfer-Encoding: 7bit$eol$eol" .
// $body . $eol;

// // fetch pdf
// $file = fopen($pdfLocation, 'rb');
// $data = fread($file, filesize($pdfLocation));
// fclose($file);
// $pdf = chunk_split(base64_encode($data));

// // attach pdf to email
// $message .= "--$mime_boundary$eol" .
// "Content-Type: $filetype;$eol" .
// " name=\"$pdfName\"$eol" .
// "Content-Disposition: attachment;$eol" .
// " filename=\"$pdfName\"$eol" .
// "Content-Transfer-Encoding: base64$eol$eol" .
// $pdf . $eol .
// "--$mime_boundary--";

// // Send the email
// if(mail($reciever, $subject, $message, $sender)) {
// echo "The email was sent.";
// }
// else {
// echo "There was an error sending the mail.";
// }

// ?>
