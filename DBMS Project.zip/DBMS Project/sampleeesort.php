<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <script src="jquery.js"></script>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./CSS/Items-Styling.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div style="overflow-x:auto;">
      <table>
        <tr>
          <th style="width: 11%;" class="column_sort" id="id" data-order="desc" href="#"> Product no.</th>
          <th style="width: 11%;"> Type</th>
          <th style="width: 13%;"> Brand</th>
          <th style="width: 20%;"> Model</th>
          <th style="width: 30%;" class="column_sort" id="price" data-order="desc" href="#"> Price</th>
          <th style="width: 30%;"> Add to Sale</th>
          <th style="width: 15%;" class="column_sort" id="quantity" data-order="desc" href="#"> Quantity in stock</th>
          <th></th>
        </tr>
      <tbody>
          <?php
            include './Partials/_dbconnect.php';
            $Query = "SELECT * FROM `item`";
            $result = mysqli_query($conn, $Query);

            $num = mysqli_num_rows($result);   //to fetch the number of rows in table

            // mysqli_fetch_assoc($res) this function returns the next row in table 
            if($num>0){
            while($row = mysqli_fetch_assoc($result)){ ?>
              <tr>
                <td> <?php echo $row['P_id'];  ?> </td>
                <td> <?php echo $row['Type'];  ?> </td>
                <td> <?php echo $row['Brand'];  ?> </td>
                <td> <?php echo $row['Model'];  ?> </td>
                <td> <?php echo $row['Price'];  ?> </td>
                <td> <?php echo "<a href='removefromcart.php?pid=$row[P_id]'><button style='font-size:24px background-color: transparent;' class='fa'>&#xf068</button></a> &nbsp&nbsp";?>
                    <?php
                        $q="SELECT * from `sale`";
                        $r=mysqli_query($conn, $q);
                        if(mysqli_num_rows($r)==0){
                          echo "0";
                        }
                        else{
                          $q="SELECT * from `sale` where `p_id`='$row[P_id]' and `status`='cart'";
                          $r=mysqli_query($conn,$q);
                          if(mysqli_num_rows($r)==0){
                            echo "0";
                          }
                          else{
                            $q=mysqli_fetch_assoc($r);
                            echo $q["quantity"];
                          }
                        }
                    ?>
                  <?php  echo "<a href='addtocart.php?pid=$row[P_id]'><button style='font-size:24px background-color: transparent;' class='fa'>&#xf067;</button></a>"; ?>
                <td> <?php echo $row['Quantity'];  ?> </td>
                <td><?php echo "<a href='Items.php?pid=$row[P_id]' onclick='return checkdel()'><button class=\"del\">Delete</button></a>" ?></td>
              </tr>  
            <?php } 
          }?>
           
      </tbody>
      </table>
    </div>
        </body>
        </html>

<script>
    $(document).ready(function(){
        $(document).on('click', '.column_sort', function(){
            var column_name = $(this).attr("id");
            var order = $(this).data("order");
            var arrow='';
            //glyphicon glyphicon-arrow-up
            //glyphicon glyphicon-arrow-down
            if(order=='desc'){
                arrow='<span class="glyphicon glyphicon-arrow-down"></span>'
            }
            else{
                arrow='<span class="glyphicon glyphicon-arrow-up"></span>'
            }
            $.ajax({
                url:"sort.php",
                method:"POST",
                data:{column_name:column_name, order:order},
                success:function(data){
                    $('#employee_table').html(data);
                    $('#'+column_name+'').append(arrow);
                }
            })
        });
    });